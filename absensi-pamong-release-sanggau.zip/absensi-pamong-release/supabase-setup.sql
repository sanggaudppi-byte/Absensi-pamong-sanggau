-- Jalankan di Supabase > SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.app_admins(user_id uuid primary key references auth.users(id) on delete cascade,created_at timestamptz default now());
create table if not exists public.attendance(id uuid primary key default gen_random_uuid(),full_name text not null check(char_length(full_name) between 2 and 120),role text not null,attendance_date date not null,attendance_time time not null,activity text not null check(char_length(activity) between 1 and 180),status text not null check(status in ('Hadir','Izin','Sakit','Alpa')),location text,notes text,evidence_path text not null,evidence_name text not null,evidence_mime text not null,created_at timestamptz not null default now());
alter table public.app_admins enable row level security;
alter table public.attendance enable row level security;

-- Fungsi SECURITY DEFINER mencegah policy app_admins membaca tabel itu sendiri
-- dan memicu RLS recursion.
create or replace function public.is_app_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.app_admins where user_id = auth.uid());
$$;
drop policy if exists "admin list" on public.app_admins;
create policy "admin list" on public.app_admins for select to authenticated using(public.is_app_admin());
drop policy if exists "public submit" on public.attendance;
create policy "public submit" on public.attendance for insert to anon,authenticated with check(status in ('Hadir','Izin','Sakit','Alpa') and evidence_path like 'evidence/%');
drop policy if exists "admin read" on public.attendance;
create policy "admin read" on public.attendance for select to authenticated using(public.is_app_admin());
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('pamong-evidence','pamong-evidence',false,8388608,array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime']) on conflict(id) do update set public=false,file_size_limit=8388608,allowed_mime_types=array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'];
drop policy if exists "public upload evidence" on storage.objects;
create policy "public upload evidence" on storage.objects for insert to anon,authenticated with check(bucket_id='pamong-evidence' and (storage.foldername(name))[1]='evidence');
drop policy if exists "admin view evidence" on storage.objects;
create policy "admin view evidence" on storage.objects for select to authenticated using(bucket_id='pamong-evidence' and exists(select 1 from public.app_admins a where a.user_id=auth.uid()));
