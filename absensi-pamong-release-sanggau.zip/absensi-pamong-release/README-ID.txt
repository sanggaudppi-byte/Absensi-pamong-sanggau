PANDUAN RILIS — ABSENSI PAMONG DIKLAT PASKIBRAKA KABUPATEN SANGGAU

Arsitektur gratis: Vercel (hosting web) + Supabase (database, login admin, file privat).

1. BUAT BACKEND SUPABASE
- Buat project di https://supabase.com.
- Buka SQL Editor, jalankan seluruh isi supabase-setup.sql.
- Buka Project Settings > API, salin Project URL dan anon/publishable key.
- Masukkan keduanya ke config.js. JANGAN gunakan service_role key.
- Authentication > Users: buat satu user admin dengan email dan password kuat. Nonaktifkan pendaftaran publik bila tersedia.
- Salin UUID user admin. Di SQL Editor jalankan:
  insert into public.app_admins(user_id) values ('UUID-ADMIN-ANDA');

2. DEPLOY WEBSITE KE VERCEL
- Unggah semua file dalam folder ini ke repositori GitHub.
- Masuk https://vercel.com, pilih Add New > Project, impor repositori.
- Framework: Other; Build Command kosong; Output Directory: .
- Deploy. Vercel memberikan alamat publik .vercel.app.

3. UJI SEBELUM RILIS
- Kirim absensi percobaan dengan foto kecil.
- Login admin dan pastikan rekap serta tautan dokumentasi berfungsi.
- Uji dari HP lain. Hapus data uji jika perlu.
- Bagikan URL Vercel kepada pamong.

KEAMANAN & BATASAN
- Data absensi tidak dapat dibaca publik melalui kebijakan database; hanya admin yang terdaftar dapat membaca.
- Dokumentasi berada di bucket privat dan dibuka admin menggunakan tautan sementara.
- Satu akun admin disiapkan dengan mendaftarkan satu UUID di app_admins.
- Jangan membagikan password admin atau anon key bersama service_role key. Service_role key tidak boleh diletakkan di website.
- Form publik belum memakai CAPTCHA/rate limit; sebelum dibagikan luas, tambahkan proteksi anti-spam melalui Edge Function/CAPTCHA.
- Supabase/Vercel free tier memiliki kuota dan ketentuan yang dapat berubah. Periksa dashboard masing-masing.
- Paket ini belum online otomatis. Pemilik perlu membuat project Supabase, mengisi config, dan melakukan deploy sesuai langkah di atas.
